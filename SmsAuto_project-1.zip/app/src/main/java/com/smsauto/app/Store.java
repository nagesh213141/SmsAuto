package com.smsauto.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** सर्व सेव्ह केलेला डेटा येथे (रोजची गणना, मर्यादा, काम, निकाल). */
public final class Store {

    public static final int HARD_MAX_LIMIT = 100;
    private static final String PREF = "smsauto";

    private Store() {
    }

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    // ---- रोजची गणना आणि मर्यादा ----

    public static synchronized int getToday(Context c) {
        SharedPreferences p = prefs(c);
        if (!todayStr().equals(p.getString("day", ""))) return 0;
        return p.getInt("count", 0);
    }

    public static synchronized void addToday(Context c, int n) {
        SharedPreferences p = prefs(c);
        String d = todayStr();
        int cur = d.equals(p.getString("day", "")) ? p.getInt("count", 0) : 0;
        p.edit().putString("day", d).putInt("count", cur + n).apply();
    }

    public static int getLimit(Context c) {
        int l = prefs(c).getInt("limit", 80);
        return Math.max(1, Math.min(HARD_MAX_LIMIT, l));
    }

    public static int setLimit(Context c, int v) {
        int clamped = Math.max(1, Math.min(HARD_MAX_LIMIT, v));
        prefs(c).edit().putInt("limit", clamped).apply();
        return clamped;
    }

    // ---- काम (job) ----

    public static synchronized JSONObject getJob(Context c) {
        String s = prefs(c).getString("job", "");
        if (s == null || s.isEmpty()) return null;
        try {
            return new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    public static synchronized void saveJob(Context c, JSONObject job) {
        prefs(c).edit().putString("job", job.toString()).apply();
    }

    public static boolean isJobActive(Context c) {
        JSONObject j = getJob(c);
        return j != null && j.optBoolean("active", false);
    }

    // ---- निकाल: { "नंबर": {"s":"sent|fail|wait", "t":वेळ(ms), "f":अयशस्वी_संख्या} } ----

    public static synchronized JSONObject getResults(Context c) {
        String s = prefs(c).getString("results", "");
        if (s == null || s.isEmpty()) return new JSONObject();
        try {
            return new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static synchronized void clearResults(Context c) {
        prefs(c).edit().remove("results").apply();
    }

    public static synchronized void putResult(Context c, String num, String status, long t, boolean addFail) {
        try {
            JSONObject r = getResults(c);
            JSONObject o = r.optJSONObject(num);
            if (o == null) o = new JSONObject();
            int f = o.optInt("f", 0);
            if (addFail) f++;
            o.put("s", status);
            o.put("t", t);
            o.put("f", f);
            r.put(num, o);
            prefs(c).edit().putString("results", r.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
