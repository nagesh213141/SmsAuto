package com.smsauto.app;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.telephony.SmsManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * रोजच्या मर्यादेपर्यंत एकामागून एक SMS पाठवते. मर्यादा संपली की अलार्म लावून थांबते
 * आणि दुसऱ्या दिवशी ठरलेल्या वेळी आपोआप पुन्हा सुरू होते. यादी संपली की स्वतः बंद होते.
 */
public class SendService extends Service {

    public static final String ACTION_SENT = "com.smsauto.app.SMS_SENT";
    public static final String ACTION_RUN = "com.smsauto.app.RUN";
    public static volatile boolean RUNNING = false;

    private static final String CHANNEL = "smsauto_run";
    private static final int NOTIF_ID = 77;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    // नंबर -> {उरलेले भाग, अयशस्वी झेंडा, एरर कोड}
    private final Map<String, int[]> pending = new HashMap<>();
    private final Set<String> triedThisRun = new HashSet<>();
    private final AtomicInteger reqCode = new AtomicInteger(5000);

    private PowerManager.WakeLock wakeLock;
    private boolean receiverRegistered = false;
    private boolean started = false;
    private String runDay = "";
    private int waitTicks = 0;

    private final Runnable stepRunnable = new Runnable() {
        @Override
        public void run() {
            step();
        }
    };

    private final BroadcastReceiver sentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String id = intent.getStringExtra("id");
            if (id == null) return;
            int rc = getResultCode();
            int[] st = pending.get(id);
            if (st == null) return;
            if (rc != Activity.RESULT_OK) {
                st[1] = 1;
                st[2] = rc;
            }
            st[0]--;
            if (st[0] <= 0) {
                boolean failed = st[1] == 1;
                pending.remove(id);
                Store.putResult(SendService.this, id, failed ? "fail" : "sent",
                        System.currentTimeMillis(), failed);
                updateNotification("आज पाठवलेले: " + Store.getToday(SendService.this)
                        + " / " + Store.getLimit(SendService.this));
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "SMS पाठवणे",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification n = buildNotification("सुरू होत आहे...", true);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Store.isJobActive(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!started) {
            started = true;
            RUNNING = true;
            runDay = Store.todayStr();
            triedThisRun.clear();
            waitTicks = 0;

            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "smsauto:send");
                wakeLock.acquire(8L * 60L * 60L * 1000L);
            }

            IntentFilter f = new IntentFilter(ACTION_SENT);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(sentReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(sentReceiver, f);
            }
            receiverRegistered = true;

            convertStaleWaits();
            handler.post(stepRunnable);
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        RUNNING = false;
        handler.removeCallbacksAndMessages(null);
        // निकाल न आलेले असतील तर ते अयशस्वी धरले जातात
        ArrayList<String> left = new ArrayList<>(pending.keySet());
        for (String n : left) {
            Store.putResult(this, n, "fail", System.currentTimeMillis(), true);
        }
        pending.clear();
        if (receiverRegistered) {
            try {
                unregisterReceiver(sentReceiver);
            } catch (Exception ignored) {
            }
            receiverRegistered = false;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    // ---------- मुख्य चक्र ----------

    private void step() {
        try {
            JSONObject job = Store.getJob(this);
            if (job == null || !job.optBoolean("active", false)) {
                finish("थांबवले.");
                return;
            }

            // रन चालू असताना दिवस बदलला तर दुसऱ्या दिवसासाठी वेगळा रन
            if (!Store.todayStr().equals(runDay)) {
                long when = Alarms.computeNext(job, false);
                Alarms.schedule(this, when);
                job.put("nextRun", when);
                Store.saveJob(this, job);
                finish("दिवस बदलला. पुढचा रन: " + fmtTime(when));
                return;
            }

            String next = findNext(job);

            if (next == null) {
                if (waitForPending()) return;
                job.put("active", false);
                Store.saveJob(this, job);
                Alarms.cancel(this);
                finish("✅ यादीतील सर्व नंबर पूर्ण झाले.");
                return;
            }

            if (Store.getToday(this) >= Store.getLimit(this)) {
                if (waitForPending()) return;
                long when = Alarms.computeNext(job, true);
                Alarms.schedule(this, when);
                job.put("nextRun", when);
                Store.saveJob(this, job);
                finish("आजची मर्यादा पूर्ण (" + Store.getToday(this) + "). पुढचा रन: " + fmtTime(when));
                return;
            }

            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                finish("SMS परवानगी नाही. ॲप उघडून परवानगी द्या.");
                return;
            }

            waitTicks = 0;
            sendOne(job, next);

            int min = Math.max(5, job.optInt("min", 60));
            int max = Math.max(min, job.optInt("max", 120));
            int sec = min + random.nextInt(max - min + 1);
            updateNotification("आज: " + Store.getToday(this) + " / " + Store.getLimit(this)
                    + "  •  पुढचा मेसेज सुमारे " + sec + " सेकंदांनी");
            handler.postDelayed(stepRunnable, sec * 1000L);
        } catch (Exception e) {
            finish("त्रुटी: " + e.getClass().getSimpleName());
        }
    }

    private boolean waitForPending() {
        if (!pending.isEmpty() && waitTicks < 12) {
            waitTicks++;
            handler.postDelayed(stepRunnable, 5000L);
            return true;
        }
        return false;
    }

    private String findNext(JSONObject job) {
        JSONArray nums = job.optJSONArray("nums");
        if (nums == null) return null;
        JSONObject res = Store.getResults(this);
        for (int i = 0; i < nums.length(); i++) {
            String n = nums.optString(i, "");
            if (n.isEmpty() || triedThisRun.contains(n)) continue;
            JSONObject o = res.optJSONObject(n);
            if (o != null) {
                String s = o.optString("s", "");
                if ("sent".equals(s)) continue;          // आधीच गेलेले: पुन्हा नाही
                if ("wait".equals(s)) continue;          // निकाल यायचा आहे
                if (o.optInt("f", 0) >= 2) continue;     // दोनदा अयशस्वी: सोडून द्या
            }
            return n;
        }
        return null;
    }

    private void sendOne(JSONObject job, String num) {
        triedThisRun.add(num);
        String msg = job.optString("msg", "");
        try {
            SmsManager sm;
            if (Build.VERSION.SDK_INT >= 31) {
                sm = getSystemService(SmsManager.class);
            } else {
                sm = SmsManager.getDefault();
            }
            ArrayList<String> parts = sm.divideMessage(msg);
            Intent i = new Intent(ACTION_SENT);
            i.setPackage(getPackageName());
            i.putExtra("id", num);
            PendingIntent pi = PendingIntent.getBroadcast(this, reqCode.incrementAndGet(), i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            ArrayList<PendingIntent> sents = new ArrayList<>();
            for (int k = 0; k < parts.size(); k++) sents.add(pi);

            pending.put(num, new int[]{parts.size(), 0, 0});
            Store.putResult(this, num, "wait", System.currentTimeMillis(), false);
            sm.sendMultipartTextMessage(num, null, parts, sents, null);
            Store.addToday(this, 1);
        } catch (Exception e) {
            pending.remove(num);
            Store.putResult(this, num, "fail", System.currentTimeMillis(), true);
        }
    }

    private void convertStaleWaits() {
        JSONObject res = Store.getResults(this);
        ArrayList<String> stale = new ArrayList<>();
        Iterator<String> it = res.keys();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject o = res.optJSONObject(k);
            if (o != null && "wait".equals(o.optString("s", ""))) stale.add(k);
        }
        for (String k : stale) {
            Store.putResult(this, k, "fail", System.currentTimeMillis(), true);
        }
    }

    private void finish(String text) {
        handler.removeCallbacks(stepRunnable);
        try {
            stopForeground(false);
        } catch (Exception ignored) {
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(text, false));
        stopSelf();
    }

    // ---------- सूचना (notification) ----------

    private String fmtTime(long when) {
        return new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date(when));
    }

    private Notification buildNotification(String text, boolean ongoing) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle("स्मार्ट एसएमएस")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentIntent(pi)
                .setOngoing(ongoing);
        return b.build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(text, true));
    }
}
