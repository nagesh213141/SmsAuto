package com.smsauto.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            JSONObject job = Store.getJob(ctx);
            if (job != null && job.optBoolean("active", false)) {
                long when = Alarms.computeNext(job, false);
                Alarms.schedule(ctx, when);
                job.put("nextRun", when);
                Store.saveJob(ctx, job);
            }
        } catch (Exception ignored) {
        }
    }
}
