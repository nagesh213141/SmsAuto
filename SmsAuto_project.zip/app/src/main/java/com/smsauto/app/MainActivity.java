package com.smsauto.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;
    private static final int REQ_PERM = 2;
    private static final int REQ_CONTACTS = 3;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("ठीक आहे", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("हो", (d, w) -> result.confirm())
                        .setNegativeButton("नाही", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "फाईल निवडा"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");

        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.SEND_SMS);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] r = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                r = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(r);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CONTACTS) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                new Thread(this::readContacts).start();
            } else {
                js("window.onContactsDenied()");
            }
        }
    }

    // ---------- helpers ----------

    private void js(final String script) {
        runOnUiThread(() -> web.evaluateJavascript(script, null));
    }

    private void startRun() {
        Intent s = new Intent(this, SendService.class);
        s.setAction(SendService.ACTION_RUN);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(s);
        } else {
            startService(s);
        }
    }

    private void readContacts() {
        JSONArray arr = new JSONArray();
        HashSet<String> seen = new HashSet<>();
        Cursor c = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String num = c.getString(1);
                    if (num == null) continue;
                    String n = num.replaceAll("[^0-9+]", "");
                    if (n.replace("+", "").length() < 10) continue;
                    if (!seen.add(n)) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", name == null ? "" : name);
                    o.put("num", n);
                    arr.put(o);
                }
            } catch (Exception ignored) {
            } finally {
                c.close();
            }
        }
        js("window.onContacts(" + arr.toString() + ")");
    }

    // ---------- JS bridge ----------

    public class Bridge {

        @JavascriptInterface
        public void loadContacts() {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS));
                return;
            }
            new Thread(MainActivity.this::readContacts).start();
        }

        @JavascriptInterface
        public int getToday() {
            return Store.getToday(MainActivity.this);
        }

        @JavascriptInterface
        public int getLimit() {
            return Store.getLimit(MainActivity.this);
        }

        @JavascriptInterface
        public int setLimit(int v) {
            return Store.setLimit(MainActivity.this, v);
        }

        @JavascriptInterface
        public void saveState(String json) {
            Store.prefs(MainActivity.this).edit().putString("state", json).apply();
        }

        @JavascriptInterface
        public String loadState() {
            return Store.prefs(MainActivity.this).getString("state", "");
        }

        @JavascriptInterface
        public String getResults() {
            return Store.getResults(MainActivity.this).toString();
        }

        @JavascriptInterface
        public void retryFailed() {
            Store.clearFailed(MainActivity.this);
        }

        @JavascriptInterface
        public void clearResults() {
            Store.clearResults(MainActivity.this);
        }

        @JavascriptInterface
        public String getStatus() {
            try {
                JSONObject job = Store.getJob(MainActivity.this);
                JSONObject o = new JSONObject();
                o.put("active", job != null && job.optBoolean("active", false));
                o.put("running", SendService.RUNNING);
                o.put("today", Store.getToday(MainActivity.this));
                o.put("limit", Store.getLimit(MainActivity.this));
                o.put("nextRun", job == null ? 0 : job.optLong("nextRun", 0));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String startAuto(String json) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_PERM));
                return "NOPERM";
            }
            try {
                JSONObject in = new JSONObject(json);
                JSONArray nums = in.optJSONArray("nums");
                String msg = in.optString("msg", "");
                if (nums == null || nums.length() == 0 || msg.isEmpty()) return "BAD";

                int min = Math.max(5, in.optInt("min", 60));
                int max = Math.max(min, in.optInt("max", 120));

                JSONObject job = new JSONObject();
                job.put("msg", msg);
                job.put("nums", nums);
                job.put("min", min);
                job.put("max", max);
                job.put("hour", in.optInt("hour", 10));
                job.put("minute", in.optInt("minute", 0));
                job.put("active", true);
                job.put("nextRun", 0);
                Store.saveJob(MainActivity.this, job);
                Alarms.cancel(MainActivity.this);
                startRun();
                return "OK";
            } catch (Exception e) {
                return "BAD";
            }
        }

        @JavascriptInterface
        public void stopAuto() {
            try {
                JSONObject job = Store.getJob(MainActivity.this);
                if (job != null) {
                    job.put("active", false);
                    Store.saveJob(MainActivity.this, job);
                }
            } catch (Exception ignored) {
            }
            Alarms.cancel(MainActivity.this);
            stopService(new Intent(MainActivity.this, SendService.class));
        }

        @JavascriptInterface
        public String saveFile(String name, String content) {
            try {
                byte[] data = content.getBytes("UTF-8");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "ERR";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    if (os == null) return "ERR";
                    os.write(data);
                    os.close();
                    return "OK";
                } else {
                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        runOnUiThread(() -> requestPermissions(
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM));
                        return "NOPERM";
                    }
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    FileOutputStream fo = new FileOutputStream(new File(dir, name));
                    fo.write(data);
                    fo.close();
                    return "OK";
                }
            } catch (Exception e) {
                return "ERR";
            }
        }

        @JavascriptInterface
        public String requestBatteryExemption() {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    return "ALREADY";
                }
                runOnUiThread(() -> {
                    try {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                });
                return "OK";
            } catch (Exception e) {
                return "ERR";
            }
        }
    }
}
