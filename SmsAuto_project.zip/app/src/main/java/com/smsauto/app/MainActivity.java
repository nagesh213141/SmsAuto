package com.smsauto.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;
    private static final int REQ_SMS = 2;
    private static final int REQ_CONTACTS = 3;
    private static final String ACTION_SENT = "com.smsauto.app.SMS_SENT";
    private static final int HARD_MAX_LIMIT = 100;

    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private final AtomicInteger reqCode = new AtomicInteger(1000);
    // id -> {remainingParts, failedFlag, errorCode}
    private final Map<String, int[]> pending = new HashMap<>();

    private final BroadcastReceiver sentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String id = intent.getStringExtra("id");
            if (id == null) return;
            int rc = getResultCode();
            boolean done = false;
            boolean failed = false;
            int err = 0;
            synchronized (pending) {
                int[] st = pending.get(id);
                if (st == null) return;
                if (rc != Activity.RESULT_OK) {
                    st[1] = 1;
                    st[2] = rc;
                }
                st[0]--;
                if (st[0] <= 0) {
                    done = true;
                    failed = st[1] == 1;
                    err = st[2];
                    pending.remove(id);
                }
            }
            if (done) {
                js("window.onSmsResult(" + JSONObject.quote(id) + "," + (!failed) + "," + err + ")");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("smsauto", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("ठीक आहे", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("हो", (d, w) -> result.confirm())
                        .setNegativeButton("नाही", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "फाईल निवडा"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        IntentFilter f = new IntentFilter(ACTION_SENT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(sentReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(sentReceiver, f);
        }

        web.loadUrl("file:///android_asset/index.html");

        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(sentReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] r = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                r = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(r);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_CONTACTS) {
            if (ok) {
                new Thread(this::readContacts).start();
            } else {
                js("window.onContactsDenied()");
            }
        }
    }

    // ---------- helpers ----------

    private void js(final String script) {
        runOnUiThread(() -> web.evaluateJavascript(script, null));
    }

    private String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private int getToday() {
        if (!todayStr().equals(prefs.getString("day", ""))) return 0;
        return prefs.getInt("count", 0);
    }

    private void addToday(int n) {
        String d = todayStr();
        int c = d.equals(prefs.getString("day", "")) ? prefs.getInt("count", 0) : 0;
        prefs.edit().putString("day", d).putInt("count", c + n).apply();
    }

    private int getLimit() {
        int l = prefs.getInt("limit", 80);
        return Math.max(1, Math.min(HARD_MAX_LIMIT, l));
    }

    private void readContacts() {
        JSONArray arr = new JSONArray();
        HashSet<String> seen = new HashSet<>();
        Cursor c = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String num = c.getString(1);
                    if (num == null) continue;
                    String n = num.replaceAll("[^0-9+]", "");
                    if (n.replace("+", "").length() < 10) continue;
                    if (!seen.add(n)) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", name == null ? "" : name);
                    o.put("num", n);
                    arr.put(o);
                }
            } catch (Exception ignored) {
            } finally {
                c.close();
            }
        }
        js("window.onContacts(" + arr.toString() + ")");
    }

    // ---------- JS bridge ----------

    public class Bridge {

        @JavascriptInterface
        public String sendSms(String id, String number, String message) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS));
                return "NOPERM";
            }
            if (getToday() >= getLimit()) return "LIMIT";
            try {
                SmsManager sm;
                if (Build.VERSION.SDK_INT >= 31) {
                    sm = getSystemService(SmsManager.class);
                } else {
                    sm = SmsManager.getDefault();
                }
                ArrayList<String> parts = sm.divideMessage(message);
                Intent intent = new Intent(ACTION_SENT);
                intent.setPackage(getPackageName());
                intent.putExtra("id", id);
                PendingIntent pi = PendingIntent.getBroadcast(
                        MainActivity.this, reqCode.incrementAndGet(), intent,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                ArrayList<PendingIntent> sentIntents = new ArrayList<>();
                for (int i = 0; i < parts.size(); i++) sentIntents.add(pi);
                synchronized (pending) {
                    pending.put(id, new int[]{parts.size(), 0, 0});
                }
                sm.sendMultipartTextMessage(number, null, parts, sentIntents, null);
                addToday(1);
                return "OK";
            } catch (Exception e) {
                synchronized (pending) {
                    pending.remove(id);
                }
                return "ERR:" + e.getClass().getSimpleName();
            }
        }

        @JavascriptInterface
        public void loadContacts() {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS));
                return;
            }
            new Thread(MainActivity.this::readContacts).start();
        }

        @JavascriptInterface
        public int getToday() {
            return MainActivity.this.getToday();
        }

        @JavascriptInterface
        public int getLimit() {
            return MainActivity.this.getLimit();
        }

        @JavascriptInterface
        public int setLimit(int v) {
            int clamped = Math.max(1, Math.min(HARD_MAX_LIMIT, v));
            prefs.edit().putInt("limit", clamped).apply();
            return clamped;
        }

        @JavascriptInterface
        public void saveState(String json) {
            prefs.edit().putString("state", json).apply();
        }

        @JavascriptInterface
        public String loadState() {
            return prefs.getString("state", "");
        }
    }
}
