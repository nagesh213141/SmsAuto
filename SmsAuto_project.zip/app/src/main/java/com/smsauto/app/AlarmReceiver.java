package com.smsauto.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (!Store.isJobActive(ctx)) return;
        Intent s = new Intent(ctx, SendService.class);
        s.setAction(SendService.ACTION_RUN);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(s);
            } else {
                ctx.startService(s);
            }
        } catch (Exception ignored) {
        }
    }
}
